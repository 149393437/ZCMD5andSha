//
//  ZCAppDelegate.h
//  加密算法
//
//  Created by ZhangCheng on 14-4-26.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
